package mancala;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Board extends JPanel implements ActionListener {

    private int count = 0;
    private JLabel label;
    private JButton button;
    private static JFrame frame;
    private JPanel panel;
    private static JLabel label1;
    private static JTextField userText;



    public Board() {
        frame = new JFrame("Mancala Game");
        frame.setBounds(50,50,2000,2000);
        Container c = frame.getContentPane();
        button = new JButton("Undo");
        button.addActionListener(this);

        label = new JLabel("You Have Undo " + count + " Times");

        panel = new JPanel();
        panel.setBorder(BorderFactory.createEmptyBorder(50, 200, 50, 200));
        panel.setLayout(new GridLayout(0, 1));
        panel.add(label);
        panel.add(button);


        label1 = new JLabel("Enter the number of stones——3 or 4 (and return): ");
        label1.setBounds(100, 100, 100, 50);
        panel.add(label1);

        userText = new JTextField();
        userText.setBounds(300, 100, 165, 50);
        userText.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String number = userText.getText();
                if (number.equals("3"))
                {
                    System.out.println("3");
                }
                else if(number.equals("4")){
                    System.out.println("4");
                }
            }
        });
        panel.add(userText);

        c.add(panel, BorderLayout.SOUTH);
    }



    public static void main(String[] args) {
        new Board();
        Draw d = new Draw();
        d.setBounds(100, 100, 1000, 1000);
        frame.add(d);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {

        if (count > 2)
        {
            return;
        }
        /**
         * when change turn, count = 0
         * undo only works when select a pit
         */

        count++;
        label.setText("You Have Undo " + count + " Times");
    }

}